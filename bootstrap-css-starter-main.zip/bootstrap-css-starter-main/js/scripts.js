1


var formIdea = document.querySelector('.form-idea');
var formIdeaTemp = formIdea.querySelector('.form-idea__temp');
var checkboxRain = formIdea.querySelector('.checkbox-rain');
var checkboxTrain = formIdea.querySelector('.checkbox-train');
var yes = document.querySelector('.yes');
var no = document.querySelector('.no');

formIdea.addEventListener('change', function () {


    if (checkboxTrain.checked && checkboxRain.checked) {
        yes.style.color = 'green';
        no.style.color = 'black';
    }
    else if (checkboxRain.checked) {
        no.style.color = 'red';
        yes.style.color = 'black';
    }
    else if (checkboxTrain.checked) {
        yes.style.color = 'green';
        no.style.color = 'black';
    }
    else if (formIdeaTemp.value.length === 0) {
        no.style.color = 'black';
        yes.style.color = 'black';
    }
    else if (formIdeaTemp.value >= 5 && formIdeaTemp.value <= 30) {
        yes.style.color = 'green';
        no.style.color = 'black';
    }
    else if (formIdeaTemp.value < 5) {
        no.style.color = 'red';
        yes.style.color = 'black';
    }
    else if (formIdeaTemp.value <= 5 && checkboxRain.checked && checkboxTrain.checked) {
        no.style.color = 'red';
        yes.style.color = 'black';
    }

});